package com.example.myapplication.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.myapplication.MenuItem

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MenuScreen(
    menuItems: List<MenuItem>,
    cartItemCount: Int,
    onAddToCart: (MenuItem) -> Unit,
    onViewCart: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Menu") },
                actions = {
                    BadgedBox(
                        badge = {
                            if (cartItemCount > 0) {
                                Badge { Text(cartItemCount.toString()) }
                            }
                        }
                    ) {
                        IconButton(onClick = onViewCart) {
                            Icon(Icons.Default.ShoppingCart, contentDescription = "Cart")
                        }
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            items(menuItems) { item ->
                MenuListItem(item, onAddToCart)
            }
        }
    }
}

@Composable
fun MenuListItem(item: MenuItem, onAddToCart: (MenuItem) -> Unit) {
    ListItem(
        headlineContent = { Text(item.name) },
        supportingContent = { Text(item.description) },
        trailingContent = {
            Column(horizontalAlignment = Alignment.End) {
                Text(text = "$${String.format("%.2f", item.price)}", style = MaterialTheme.typography.bodyLarge)
                IconButton(onClick = { onAddToCart(item) }) {
                    Icon(Icons.Default.Add, contentDescription = "Add to cart")
                }
            }
        },
        modifier = Modifier.clickable { /* Show details if needed */ }
    )
    Divider()
}
