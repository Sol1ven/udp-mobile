package com.example.myapplication.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.myapplication.Order
import com.example.myapplication.OrderStatus
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderHistoryScreen(orders: List<Order>, onOrderClick: (Order) -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Order History") })
        }
    ) { padding ->
        if (orders.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = androidx.compose.ui.Alignment.Center) {
                Text("No orders yet")
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                items(orders) { order ->
                    OrderListItem(order, onOrderClick)
                }
            }
        }
    }
}

@Composable
fun OrderListItem(order: Order, onClick: (Order) -> Unit) {
    val dateFormat = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
    val dateString = dateFormat.format(Date(order.timestamp))

    ListItem(
        headlineContent = { Text("Order #${order.id.takeLast(6)}") },
        supportingContent = {
            Column {
                Text(dateString)
                Text(
                    text = order.status.name.replace("_", " ").lowercase().replaceFirstChar { it.uppercase() },
                    color = getStatusColor(order.status)
                )
            }
        },
        trailingContent = {
            Text(text = "$${String.format("%.2f", order.totalAmount)}", style = MaterialTheme.typography.bodyLarge)
        },
        modifier = Modifier.clickable { onClick(order) }
    )
    HorizontalDivider()
}

@Composable
fun getStatusColor(status: OrderStatus) = when (status) {
    OrderStatus.RECEIVED -> MaterialTheme.colorScheme.primary
    OrderStatus.PREPARING -> MaterialTheme.colorScheme.secondary
    OrderStatus.READY_FOR_PICKUP -> MaterialTheme.colorScheme.tertiary
    OrderStatus.COMPLETED -> MaterialTheme.colorScheme.outline
}
