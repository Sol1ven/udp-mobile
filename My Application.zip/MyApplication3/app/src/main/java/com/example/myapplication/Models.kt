package com.example.myapplication

data class MenuItem(
    val id: String = "",
    val name: String = "",
    val description: String = "",
    val price: Double = 0.0,
    val category: String = ""
)

data class Order(
    val id: String = "",
    val items: List<OrderItem> = emptyList(),
    val totalAmount: Double = 0.0,
    val status: OrderStatus = OrderStatus.RECEIVED,
    val timestamp: Long = 0L
)

data class OrderItem(
    val menuItem: MenuItem = MenuItem(),
    val quantity: Int = 0
)

enum class OrderStatus {
    RECEIVED, PREPARING, READY_FOR_PICKUP, COMPLETED
}

data class UserProfile(
    val name: String = "",
    val email: String = "",
    val rfidCardId: String? = null,
    val rfidBalance: Double = 0.0
)
