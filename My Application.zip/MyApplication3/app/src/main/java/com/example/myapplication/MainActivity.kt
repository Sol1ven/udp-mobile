package com.example.myapplication

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.RestaurantMenu
import androidx.compose.material.icons.filled.SdCard
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.lifecycleScope
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.myapplication.ui.screens.*
import com.example.myapplication.ui.theme.MyApplicationTheme
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.*

class MainActivity : ComponentActivity() {
    private val channelId = "order_status_channel"
    private lateinit var db: com.google.firebase.firestore.FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        if (FirebaseApp.getApps(this).isEmpty()) {
            FirebaseApp.initializeApp(this)
        }
        
        db = Firebase.firestore
        val settings = FirebaseFirestoreSettings.Builder()
            .setPersistenceEnabled(true)
            .build()
        db.firestoreSettings = settings

        createNotificationChannel()
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainApp(
                    onOrderPlaced = { order ->
                        saveOrderToFirestore(order)
                        simulateOrderFlow(order.id)
                    }
                )
            }
        }
    }

    private fun saveOrderToFirestore(order: Order) {
        lifecycleScope.launch {
            try {
                db.collection("orders").document(order.id).set(order).await()
            } catch (e: Exception) {
                Log.e("Firestore", "Error saving order", e)
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Order Status"
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel(channelId, name, importance)
            val notificationManager: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun sendNotification(title: String, message: String) {
        val builder = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)

        with(NotificationManagerCompat.from(this)) {
            try {
                notify(System.currentTimeMillis().toInt(), builder.build())
            } catch (_: SecurityException) {}
        }
    }

    private fun simulateOrderFlow(orderId: String) {
        lifecycleScope.launch {
            sendNotification("Order Received", "We've got your order #$orderId!")
            delay(5000)
            updateOrderStatus(orderId, OrderStatus.PREPARING)
            sendNotification("Order Preparing", "Your order #$orderId is being prepared.")
            delay(10000)
            updateOrderStatus(orderId, OrderStatus.READY_FOR_PICKUP)
            sendNotification("Ready for Pickup", "Your order #$orderId is ready for pickup!")
        }
    }

    private fun updateOrderStatus(orderId: String, status: OrderStatus) {
        db.collection("orders").document(orderId)
            .update("status", status)
            .addOnFailureListener { e -> Log.e("Firestore", "Update failed", e) }
    }
}

@Composable
fun MainApp(onOrderPlaced: (Order) -> Unit) {
    val navController = rememberNavController()
    var isLoggedIn by remember { mutableStateOf(false) }
    val db = remember { Firebase.firestore }
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    
    var userProfile by remember { mutableStateOf(UserProfile("John Doe", "john.doe@example.com", null, 50.0)) }
    var menuItems by remember { mutableStateOf<List<MenuItem>?>(null) } // null = loading
    var orders by remember { mutableStateOf(listOf<Order>()) }
    var cartItems by remember { mutableStateOf(listOf<OrderItem>()) }

    // Sync Data
    LaunchedEffect(isLoggedIn) {
        // Menu Listen
        db.collection("menu").addSnapshotListener { snapshot, e ->
            if (e != null) {
                scope.launch { snackbarHostState.showSnackbar("Firestore Error: ${e.message}") }
                return@addSnapshotListener
            }
            if (snapshot != null) {
                val items = snapshot.toObjects(MenuItem::class.java)
                if (items.isEmpty()) {
                    // Seed initial data if database is empty
                    val seed = listOf(
                        MenuItem("1", "Classic Burger", "Beef patty", 12.99, "Food"),
                        MenuItem("2", "Iced Latte", "Chilled espresso", 4.50, "Drinks")
                    )
                    seed.forEach { db.collection("menu").document(it.id).set(it) }
                } else {
                    menuItems = items
                }
            }
        }

        if (isLoggedIn) {
            // Profile & Orders Listen
            db.collection("users").document("current_user").addSnapshotListener { snapshot, _ ->
                if (snapshot != null && snapshot.exists()) {
                    userProfile = snapshot.toObject(UserProfile::class.java) ?: userProfile
                }
            }
            db.collection("orders").orderBy("timestamp").addSnapshotListener { snapshot, _ ->
                if (snapshot != null) orders = snapshot.toObjects(Order::class.java)
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            if (isLoggedIn) {
                NavigationBar {
                    val items = listOf(
                        Triple("menu", "Menu", Icons.Default.RestaurantMenu),
                        Triple("rfid", "RFID", Icons.Default.SdCard),
                        Triple("orders", "Orders", Icons.Default.History),
                        Triple("profile", "Profile", Icons.Default.Person)
                    )
                    val navBackStackEntry by navController.currentBackStackEntryAsState()
                    val currentDestination = navBackStackEntry?.destination
                    items.forEach { (route, label, icon) ->
                        NavigationBarItem(
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label) },
                            selected = currentDestination?.hierarchy?.any { it.route == route } == true,
                            onClick = {
                                navController.navigate(route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        if (!isLoggedIn) {
            LoginScreen(onLoginSuccess = { isLoggedIn = true })
        } else {
            NavHost(navController, startDestination = "menu", Modifier.padding(innerPadding)) {
                composable("menu") {
                    if (menuItems == null) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator()
                        }
                    } else {
                        MenuScreen(
                            menuItems = menuItems!!,
                            cartItemCount = cartItems.sumOf { it.quantity },
                            onAddToCart = { item ->
                                val existing = cartItems.find { it.menuItem.id == item.id }
                                cartItems = if (existing != null) {
                                    cartItems.map { if (it.menuItem.id == item.id) it.copy(quantity = it.quantity + 1) else it }
                                } else {
                                    cartItems + OrderItem(item, 1)
                                }
                            },
                            onViewCart = { navController.navigate("cart") }
                        )
                    }
                }
                composable("cart") {
                    CartScreen(
                        cartItems = cartItems,
                        rfidBalance = userProfile.rfidBalance,
                        onRemoveItem = { item -> cartItems = cartItems.filter { it != item } },
                        onPlaceOrder = { method ->
                            val total = cartItems.sumOf { it.menuItem.price * it.quantity }
                            if (method == "RFID") {
                                db.collection("users").document("current_user").update("rfidBalance", userProfile.rfidBalance - total)
                            }
                            val order = Order(UUID.randomUUID().toString().take(8).uppercase(), cartItems, total, OrderStatus.RECEIVED, System.currentTimeMillis())
                            cartItems = emptyList()
                            onOrderPlaced(order)
                            navController.navigate("receipt/${order.id}")
                        },
                        onBack = { navController.popBackStack() }
                    )
                }
                composable("rfid") {
                    RFIDScreen(userProfile, 
                        onConnectRFID = { db.collection("users").document("current_user").update("rfidCardId", "RFID-12345") },
                        onReloadBalance = { amt -> db.collection("users").document("current_user").update("rfidBalance", userProfile.rfidBalance + amt) }
                    )
                }
                composable("orders") { OrderHistoryScreen(orders) { navController.navigate("receipt/${it.id}") } }
                composable("profile") { ProfileScreen(userProfile) { isLoggedIn = false } }
                composable("receipt/{orderId}") { entry ->
                    val order = orders.find { it.id == entry.arguments?.getString("orderId") }
                    if (order != null) ReceiptScreen(order) { navController.popBackStack("menu", false) }
                }
            }
        }
    }
}
