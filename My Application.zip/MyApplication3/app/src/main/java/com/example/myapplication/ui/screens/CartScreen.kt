package com.example.myapplication.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.myapplication.OrderItem

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CartScreen(
    cartItems: List<OrderItem>,
    rfidBalance: Double,
    onRemoveItem: (OrderItem) -> Unit,
    onPlaceOrder: (paymentMethod: String) -> Unit,
    onBack: () -> Unit
) {
    val total = cartItems.sumOf { it.menuItem.price * it.quantity }
    var showPaymentDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Your Cart") })
        }
    ) { padding ->
        if (cartItems.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("Your cart is empty")
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                LazyColumn(modifier = Modifier.weight(1f)) {
                    items(cartItems) { item ->
                        ListItem(
                            headlineContent = { Text(item.menuItem.name) },
                            supportingContent = { Text("Qty: ${item.quantity} - $${String.format("%.2f", item.menuItem.price * item.quantity)}") },
                            trailingContent = {
                                IconButton(onClick = { onRemoveItem(item) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Remove")
                                }
                            }
                        )
                        HorizontalDivider()
                    }
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Total:", style = MaterialTheme.typography.headlineSmall)
                            Text("$${String.format("%.2f", total)}", style = MaterialTheme.typography.headlineSmall)
                        }
                        
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        Button(
                            onClick = { showPaymentDialog = true },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Proceed to Payment")
                        }
                    }
                }
            }
        }
    }

    if (showPaymentDialog) {
        AlertDialog(
            onDismissRequest = { showPaymentDialog = false },
            title = { Text("Select Payment Method") },
            text = {
                Column {
                    Text("Total: $${String.format("%.2f", total)}")
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = {
                            onPlaceOrder("Online")
                            showPaymentDialog = false
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Pay Online (Card/Wallet)")
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = {
                            if (rfidBalance >= total) {
                                onPlaceOrder("RFID")
                                showPaymentDialog = false
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = rfidBalance >= total
                    ) {
                        Text("Pay with RFID (Bal: $${String.format("%.2f", rfidBalance)})")
                    }
                    if (rfidBalance < total) {
                        Text(
                            "Insufficient RFID balance",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showPaymentDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
