package com.example.myapplication.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.myapplication.UserProfile

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RFIDScreen(
    userProfile: UserProfile,
    onConnectRFID: () -> Unit,
    onReloadBalance: (Double) -> Unit
) {
    var showReloadDialog by remember { mutableStateOf(false) }
    var reloadAmount by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("RFID Card") })
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.CreditCard,
                contentDescription = null,
                modifier = Modifier.size(120.dp),
                tint = MaterialTheme.colorScheme.primary
            )

            Spacer(modifier = Modifier.height(24.dp))

            if (userProfile.rfidCardId == null) {
                Text(
                    text = "No RFID card connected",
                    style = MaterialTheme.typography.bodyLarge
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(onClick = onConnectRFID) {
                    Text("Connect RFID Card")
                }
            } else {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Current Balance",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = "$${String.format("%.2f", userProfile.rfidBalance)}",
                            style = MaterialTheme.typography.headlineLarge,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Card ID: ${userProfile.rfidCardId}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = { showReloadDialog = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Payment, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Reload Balance")
                }
            }
        }
    }

    if (showReloadDialog) {
        AlertDialog(
            onDismissRequest = { showReloadDialog = false },
            title = { Text("Reload Balance") },
            text = {
                Column {
                    Text("Enter amount to reload via online payment")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = reloadAmount,
                        onValueChange = { reloadAmount = it },
                        label = { Text("Amount ($)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val amount = reloadAmount.toDoubleOrNull() ?: 0.0
                        if (amount > 0) {
                            onReloadBalance(amount)
                            showReloadDialog = false
                            reloadAmount = ""
                        }
                    }
                ) {
                    Text("Pay Now")
                }
            },
            dismissButton = {
                TextButton(onClick = { showReloadDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
